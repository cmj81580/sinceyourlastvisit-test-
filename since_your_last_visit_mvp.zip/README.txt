Deployment instructions: 
1. Open index.html in your browser.
2. Or upload the folder to Netlify or GitHub Pages.